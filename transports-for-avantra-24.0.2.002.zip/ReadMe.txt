All supported SAP basis releases (see installation guide)
---------------------------------------------------------
********************************************************************************************************************************************
*
* VERY IMPORTANT FOR AVANTRA AUTOMATION CUSTOMERS!!!
*
* As of Avantra 24 for all Avantra Automation customers using the SAP Release ≥ 7.30 SP 5 transports there is no longer a requirement 
* to import these transports. ONLY THE AVANTRA AUTOMATION TRANSPORTS SHOULD BE IMPORTED!!
*
* The automation transports can be found in the solution document
* https://support.avantra.com/en/support/solutions/articles/44002349022-how-to-guide-sap-automation-templates-installation  
*
********************************************************************************************************************************************

Workbench request:
AVAK900628: Avantra Interface V24.0.2.002 for all SAP Release ≥ 7.30 SP 5 *
XANK900264: Avantra Interface V7 for SAP Release 7.30 SP4 and lower *
* SAP_BASIS patch level

Customizing request (client dependent):
Please make sure that the profile of role ZAVANTRA / ZAVANTRA_SOLMAN is generated. You can check/regenerate with transaction PFCG.
ASMK900016: Role for Avantra (ZAVANTRA_SOLMAN) Solman systems only --> user in Solman needs both roles ZAVANTRA and ZAVANTRA_SOLMAN
XANK900262: Role for Avantra (ZAVANTRA) SAP Release 7.30 SP4 and lower *
AVAK900624: Role ZAVANTRA V24.0.2.002 for all SAP Release ≥ 7.30 SP5 *
* SAP_BASIS patch level

